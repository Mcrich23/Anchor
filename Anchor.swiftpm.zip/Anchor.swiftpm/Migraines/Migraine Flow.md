#  Migraine Flow

## Take Medication

## Calming Activities

- Breathing Excersise
- Drawing

# Sources
https://www.mayoclinic.org/diseases-conditions/migraine-headache/in-depth/migraines/art-20047242
https://www.nhs.uk/conditions/migraine/
https://www.verywellhealth.com/migraine-light-therapy-4114138#:~:text=Research%20that%20has%20looked%20at,light%20can%20actually%20be%20therapeutic.

#  Sources

## Coding
- https://bigmountainstudio.wordpress.com/2020/07/26/394/
- https://github.com/Enryun/Flowers
- https://developer.apple.com/tutorials/app-dev-training/transcribing-speech-to-text

## Color Science
- https://www.verywellhealth.com/migraine-light-therapy-4114138
- https://www.moffitt.org/endeavor/archive/color-your-world-to-relieve-stress/#:~:text=Blue%20–%20A%20highly%20peaceful%20color,feeling%20that%20helps%20reduce%20stress

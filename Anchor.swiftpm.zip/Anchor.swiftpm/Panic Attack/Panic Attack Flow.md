#  Panic Attack Flow

## Acknowledge ✅

- Repeat mantra (live microphone feedback)

## Grounding
    
- Find a calm location
- Take Deep Breaths ✅
- Focus on Object
- 5-4-3-2-1 Method (maybe not possible)
    1. Look at 5 different object
    2. Listen to 4 distinc sounds
    3. Touch 3 objects
    4. Identify 2 smells
    5. Name 1 thing you can taste
- Walk around
- Muscle Relaxation
- Picture a Happy Place
    - Drawing? ✅

# Sources
https://www.medicalnewstoday.com/articles/321510#methods
Conversation with Dr. Matthew Hopperstad
https://www.actmindfully.com.au/upimages/Dropping_anchor_script.pdf
https://www.flourishmindfully.com.au/blog/dropping-anchor
